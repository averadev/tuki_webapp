<?php

class Reward extends eloquent{
	
	protected table = "reward";
	protected $SoftDelete = false;
	
}