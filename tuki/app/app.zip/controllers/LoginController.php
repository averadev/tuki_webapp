<?php

class LoginController extends BaseController {
	/*
	|--------------------------------------------------------------------------
	| Controlador para el login
	|--------------------------------------------------------------------------
	|
	*/

	public function getIndex(){
		if(Auth::check()){
			$id = Auth::id();
			$data = Commerce::find($id);
			$now = new DateTime();
  			$month = $now->format('n');
			$dataChart = json_encode(Log_new_user_commerce::getDataByMonth($data,'03'));					
			return View::make('welcome.home')
			->with('commerce',$data)
			->with('chartcom',$dataChart)
			->with('month',$month);	

		}
		return View::make('login.login');
	}

	public function postLogIn(){
		if(Request::ajax()){
			$data = [
				'nombre'   => trim(Input::get('user')),
				'password' => trim(Input::get('pass'))
			];
			$rules = [
				'nombre'   => 'required',
				'password' => 'required'
			];
			$validator = Validator::make($data,$rules);
			if( $validator->passes() ){
				if (Auth::attempt($data)){
					return Response::json(array('success'=>true),200);
				}else{
					return Response::json(array('success'=>false),200);
				}
			}
			return Redirect::back()->with('errorLogin',true);
		}
	}

	public function getMakeCharts(){
		if(Request::ajax()){
			$data = [
				'commerce'	=> trim(Input::get('commerce')),
				'month'   	=> trim(Input::get('month')),
				'chartType' => trim(Input::get('chart'))
			];
			$rules = [
				'commerce' 	=> 'required',
				'month'   	=> 'required',
				'chartType' => 'required'
			];
			$validator = Validator::make($data,$rules);
			if( $validator->passes() ){
				$data = (object)$data;
				if($data->chartType == 1){
					$dataChart = Log_new_user_commerce::getDataByMonth($data->commerce,$data->month);
					return Response::json(array('success' => true,'data' => $dataChart,'chart'=>1,),200);
				}
				if($data->chartType == 2){
					$dataChart = Log_user_checkin::getDataByMonth($data->commerce,$data->month);
					return Response::json(array('success' => true,'data' => $dataChart,'chart'=>2),200);
				}
				if($data->chartType == 3){
					$dataChart = Redemption::getDataByMonth($data->commerce,$data->month);
					return Response::json(array('success' => true,'data' => $dataChart,'chart'=>3),200);
				}
			}
		}
	}

	public function getLogout(){
		Auth::logout();
		return Redirect::to('/');
	}


}
