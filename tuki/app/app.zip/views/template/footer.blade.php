<footer>
	<div class="row expanded margin-top-20">
		<div class="medium-6 columns">
			<ul class="menu">
				<li><a href="#">Recompensas</a></li>
				<li><a href="#">Reporte</a></li>
				<li><a href="#">Mi comercio</a></li>
			</ul>
		</div>
		<div class="medium-6 columns">
			<ul class="menu align-right">
			<li class="menu-text"></li>
			</ul>
		</div>
	</div>
</footer>