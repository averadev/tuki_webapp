<div class="top-bar white-color">
<div class="top-bar-left">
	<img class="header-logo left" src="vendor/login/logo.png" alt="tuki" />
</div>
	<div class="top-bar-right listblock">
		<ul class="menu">
			<li> 
				<a href="{{URL::to('/')}}" >
					<img style="width: 50px; height: 43px; font-family: HelveticaNeuel;" class="" src="{{ $commerce->image }}" alt="logo" />
				</a>  
			</li>
			<li>  
				<a href="{{URL::to('/logout')}}" >
					<img class="" src="vendor/img/log_out.png" alt="logout" />
				</a>  
			</li>
		</ul>
	</div>
</div>